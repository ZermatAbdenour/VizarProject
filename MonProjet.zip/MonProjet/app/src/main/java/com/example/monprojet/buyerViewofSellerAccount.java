package com.example.monprojet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class buyerViewofSellerAccount extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer_viewof_seller_account);
    }
}