package com.example.monprojet;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class personalAccountView extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personal_account_view);
    }
}